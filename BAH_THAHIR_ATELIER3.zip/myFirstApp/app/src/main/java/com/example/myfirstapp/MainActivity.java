package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editTextFistName;
    EditText editTextLastName;
    private DBManager dbManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        dbManager = new DBManager(this);
        dbManager.open();
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        editTextFistName = findViewById(R.id.editTextTextPersonFirstName);
        String firstName = editTextFistName.getText().toString();
        editTextLastName = findViewById(R.id.editTextTextPersonLastName);
        String lastName = editTextLastName.getText().toString();
        dbManager.insert(firstName, lastName);
        startActivity(intent);
    }
}