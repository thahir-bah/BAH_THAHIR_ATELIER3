package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import java.sql.SQLException;

public class DisplayMessageActivity extends AppCompatActivity {

    private DBManager dbManager;
    private SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        dbManager = new DBManager(this);
        dbManager.open();
        Cursor cursor = dbManager.fetch();

        String firstName = cursor.getString(1) + " ";
        String lastName = cursor.getString(2) + "!";

        TextView textViewFirstName = findViewById(R.id.textViewPersonFirstName);
        TextView textViewLastName = findViewById(R.id.textViewPersonLastName);


        textViewFirstName.setText(firstName);
        textViewLastName.setText(lastName);


    }
}