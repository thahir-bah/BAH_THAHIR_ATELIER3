package com.example.myfirstapp;
// Class to perform all database CRUD(Create, Read, Update and Delete) operations

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import java.sql.SQLException;
import android.database.Cursor;
public class DBManager {

    DatabaseHelper dbHelper;
    Context context;
    SQLiteDatabase database;

    public DBManager(Context c) {
        context = c;
    }

    public DBManager open()  {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert(String firstname, String lastname) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.FIRSTNAME, firstname);
        contentValue.put(DatabaseHelper.LASTNAME, lastname);
        database.insert(DatabaseHelper.TABLE_NAME, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[] { DatabaseHelper._ID, DatabaseHelper.FIRSTNAME, DatabaseHelper.LASTNAME };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToLast();
        }
        return cursor;
    }

}
